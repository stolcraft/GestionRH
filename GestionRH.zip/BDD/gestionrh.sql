-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  mar. 09 juil. 2019 à 15:11
-- Version du serveur :  5.7.21
-- Version de PHP :  5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `gestionrh`
--
CREATE DATABASE IF NOT EXISTS `gestionrh` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `gestionrh`;

-- --------------------------------------------------------

--
-- Structure de la table `demandedeformation`
--

DROP TABLE IF EXISTS `demandedeformation`;
CREATE TABLE IF NOT EXISTS `demandedeformation` (
  `ID` varchar(50) NOT NULL,
  `IDPersonnel` varchar(50) NOT NULL,
  `IDFormation` varchar(50) NOT NULL,
  `Statut` varchar(50) NOT NULL,
  `Message` varchar(150) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `demandedeformation`
--

INSERT INTO `demandedeformation` (`ID`, `IDPersonnel`, `IDFormation`, `Statut`, `Message`) VALUES
('0', '0', '0', 'Accepter', 'Valider');

-- --------------------------------------------------------

--
-- Structure de la table `formationencour`
--

DROP TABLE IF EXISTS `formationencour`;
CREATE TABLE IF NOT EXISTS `formationencour` (
  `ID` varchar(50) NOT NULL,
  `Theme` varchar(50) NOT NULL,
  `DateDebut` date NOT NULL,
  `Duree` float NOT NULL,
  `Description` varchar(150) NOT NULL,
  `Active` tinyint(1) NOT NULL,
  `IDManager` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `formationencour`
--

INSERT INTO `formationencour` (`ID`, `Theme`, `DateDebut`, `Duree`, `Description`, `Active`, `IDManager`) VALUES
('0', 'java', '2019-07-12', 4, 'on va bine s\'amuser en java', 0, '1');

-- --------------------------------------------------------

--
-- Structure de la table `salarie`
--

DROP TABLE IF EXISTS `salarie`;
CREATE TABLE IF NOT EXISTS `salarie` (
  `ID` varchar(50) NOT NULL,
  `Nom` varchar(50) NOT NULL,
  `Prenom` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Adresse` varchar(150) NOT NULL,
  `Fonction` varchar(50) NOT NULL,
  `DateEmbauche` date NOT NULL,
  `Statut` varchar(50) NOT NULL,
  `Login` varchar(50) NOT NULL,
  `Mdp` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `salarie`
--

INSERT INTO `salarie` (`ID`, `Nom`, `Prenom`, `Email`, `Adresse`, `Fonction`, `DateEmbauche`, `Statut`, `Login`, `Mdp`) VALUES
('0', 'jachy', 'chan', 'jacky.chan@gmail.com', '2 rue de kung fu 89930 paris', 'cascadeur', '2019-07-02', 'employe', 'test', 'test'),
('1', 'pierre', 'duval', 'pierre.duval@gmail.com', '3 rue de la pizza pino 99999 nice', 'manager', '2019-07-04', 'manager', 'test2', 'test'),
('2', 'melanie', 'testaire', 'melanie.testaire@gmail.com', '34 rue du soleil levant 3309 paris', 'charge ressource humaine', '2019-07-01', 'rh', 'test3', 'test');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
