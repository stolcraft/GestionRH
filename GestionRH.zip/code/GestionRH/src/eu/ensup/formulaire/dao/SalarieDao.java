package eu.ensup.formulaire.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import eu.ensup.formulaire.domaine.Formation;
import eu.ensup.formulaire.domaine.FormationDemande;
import eu.ensup.formulaire.domaine.Personne;

public class SalarieDao extends AccesBd {

	public static ArrayList<Formation> listerFormation(){
		Formation formation = new Formation();
		ArrayList<Formation> listeFormation = new ArrayList();
		//take a list to store the values which are in db
		try{  
			Connection con= AccesBd.seConnecter();  
			PreparedStatement ps=con.prepareStatement("select * from formationencour");  
			ResultSet rs =ps.executeQuery();  
			if(rs.next()){  				
				formation.setId(rs.getString("ID"));
				formation.setTheme(rs.getString("Theme"));
				formation.setDateDebut(rs.getDate("DateDebut"));
				formation.setDuree(rs.getFloat("Duree"));
				formation.setDescription(rs.getString("Description"));
				formation.setActif(rs.getBoolean("Active"));
				formation.setIdmanager(rs.getString("IDManager"));
				
				listeFormation.add(formation);
			} 
			con.close();  
		}catch(Exception ex){ex.printStackTrace();}  

		return listeFormation;

	}
	
	public static ArrayList<FormationDemande> listerFormationDemande(String id){
		System.out.println("on est laaaa");
		System.out.println("iD : "+id);
		FormationDemande formationdemande = new FormationDemande();
		ArrayList<FormationDemande> listeformationdemande = new ArrayList();
		//take a list to store the values which are in db
		try{  
			Connection con= AccesBd.seConnecter();  
			PreparedStatement ps=con.prepareStatement("select * from formationencour, demandedeformation where demandedeformation.IDFormation = formationencour.ID and demandedeformation.IDPersonnel=? ORDER BY demandedeformation.ID");  
			ps.setString(1,id);
			ResultSet rs =ps.executeQuery();  
			if(rs.next()){  				
				formationdemande.setID(rs.getString("ID"));
				formationdemande.setTheme(rs.getString("Theme"));
				formationdemande.setStatut(rs.getString("Statut"));
				formationdemande.setMessage(rs.getString("Message"));
				
				System.out.println("formationdemande : "+ formationdemande);
				
				listeformationdemande.add(formationdemande);
			} 
			con.close();  
		}catch(Exception ex){ex.printStackTrace();}  

		return listeformationdemande;

	}
}
