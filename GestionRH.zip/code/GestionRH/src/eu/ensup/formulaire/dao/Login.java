package eu.ensup.formulaire.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import eu.ensup.formulaire.domaine.Personne;




public class Login {

	public static Personne loginUtilisateur(String login,String pwd){
		Personne personne = new Personne();
		//take a list to store the values which are in db
		try{  
			Connection con= AccesBd.seConnecter();  
			PreparedStatement ps=con.prepareStatement("select * from salarie where Login=? and Mdp=?");  
			ps.setString(1,login);  
			ps.setString(2,pwd);
			ResultSet rs =ps.executeQuery();  
			if(rs.next()){  				
				personne.setNom(rs.getString("Nom"));
				personne.setPrenom(rs.getString("Prenom"));
				personne.setId(rs.getString("ID"));
				personne.setStatut(rs.getString("Statut"));
				personne.setLogin(rs.getString("Login"));
				
				personne.setAdresse(rs.getString("Adresse"));
				personne.setDate(rs.getDate("DateEmbauche"));
				personne.setFonction(rs.getString("Fonction"));
				personne.setMdp(rs.getString("Mdp"));
				personne.setMail(rs.getString("Email"));
			}  
			System.out.println("personne" + personne);
			con.close();  
		}catch(Exception ex){ex.printStackTrace();}  

		return personne;

	}
}
