package eu.ensup.formulaire.domaine;

public class FormationDemande {

	private String ID;
	private String Statut;
	private String Message;
	private String theme;
	public FormationDemande() {
		super();
	}
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getStatut() {
		return Statut;
	}
	public void setStatut(String statut) {
		Statut = statut;
	}
	public String getMessage() {
		return Message;
	}
	public void setMessage(String message) {
		Message = message;
	}
	public String getTheme() {
		return theme;
	}
	public void setTheme(String theme) {
		this.theme = theme;
	}
	@Override
	public String toString() {
		return "FormationDemande [ID=" + ID + ", Statut=" + Statut + ", Message=" + Message + ", theme=" + theme + "]";
	}
	
	
}
