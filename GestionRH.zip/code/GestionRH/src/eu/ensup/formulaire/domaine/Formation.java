package eu.ensup.formulaire.domaine;

import java.util.Date;

public class Formation {

	private String id;
	private String theme;
	private Date dateDebut;
	private float duree;
	private String Description;
	private boolean actif;
	private String idmanager;
	public Formation() {
		super();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTheme() {
		return theme;
	}
	public void setTheme(String theme) {
		this.theme = theme;
	}
	public Date getDateDebut() {
		return dateDebut;
	}
	public void setDateDebut(Date dateDebut) {
		this.dateDebut = dateDebut;
	}
	public float getDuree() {
		return duree;
	}
	public void setDuree(float duree) {
		this.duree = duree;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public boolean isActif() {
		return actif;
	}
	public void setActif(boolean actif) {
		this.actif = actif;
	}
	public String getIdmanager() {
		return idmanager;
	}
	public void setIdmanager(String idmanager) {
		this.idmanager = idmanager;
	}
	@Override
	public String toString() {
		return "Formation [id=" + id + ", theme=" + theme + ", dateDebut=" + dateDebut + ", duree=" + duree
				+ ", Description=" + Description + ", actif=" + actif + ", idmanager=" + idmanager + "]";
	}
	
}
