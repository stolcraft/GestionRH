------------------------------------
Merci d'avoir choisis notre soci�t�
------------------------------------

Pour faire fonctionner l'application :
- Mettre le fichier WAR sur un serveur web (tomcat)
- Importer le fichier gestionrh.sql sous MySql
- Connecter vous sur votre localhost
- Choisssisez un compte et connecter-vous

les comptes disponibles:

- Employe login : test / mdp : test
- Manager login : test1 / mdp: test
- RH login : test2 / mdp : test


Une documentation est disponible dans le dossier documentation
Des diagrammes sont disponibles dans le dossier Diagramme UML

Et profitez! 